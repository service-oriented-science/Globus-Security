package org.globus.security.authorization.impl;


public class DefaultAuthorizationBus implements AuthorizationBus {	
//	private I18n i18n = I18n.getI18n("errors.properties");

	public AuthorizationEngine getAdminAuthorizationEngine() {
		// TODO Auto-generated method stub
		return null;
	}

	public AuthorizationEngine getContainerAuthorizationEngine() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setAdminAuthorizationEngine(AuthorizationEngine engine) {
		// TODO Auto-generated method stub
		
	}		
}
